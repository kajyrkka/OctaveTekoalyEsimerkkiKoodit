clear;


asunnonNelioMaara = 30 + round(270*rand(1,100));
asunnonHinta=[];
for I = 1:length(asunnonNelioMaara)
 asunnonHinta(I) = asunnonNelioMaara(I)*(1000+round(2000*rand(1)));
endfor

save data asunnonNelioMaara asunnonHinta

figure(1);plot(asunnonNelioMaara,asunnonHinta,'r*',"markersize",10)
title('Toteutuneiden asuntokauppojen hinnat',"fontsize",20)
xlabel('Asuntojen neliom��r�t',"fontsize",20)
ylabel('Asuntojen hinnat',"fontsize",20)
grid



