%
% Regressio algoritmin toteutus
%

% tehd��n ensin data, opetusta verten
load data;
M = 100; % Tunnettujen datapisteiden lukumaara
figure(1);plot(asunnonNelioMaara,asunnonHinta,'r*',"markersize",10)
title('Toteutuneiden asuntokauppojen hinnat',"fontsize",20)
xlabel('Asuntojen neliom��r�t',"fontsize",20)
ylabel('Asuntojen hinnat',"fontsize",20)
grid;hold on

figure(4);plot(asunnonNelioMaara,asunnonHinta,'r*',"markersize",10)
title('Toteutuneiden asuntokauppojen hinnat',"fontsize",20)
xlabel('Asuntojen neliom��r�t',"fontsize",20)
ylabel('Asuntojen hinnat',"fontsize",20)
grid;hold on


% Yritet��n sovittaa suora datapisteisiin regressio algoritmin avulla
% arvotaan suoran kulmakertoimelle ja vakio-osalle satunnaiset
% alkuarvot
k = 10000*randn(1);
b = 10000*randn(1);
xakseli = 30:300;
arvattuSuora = k*xakseli + b;
figure(1);plot(xakseli,arvattuSuora,'-b');
hold off



% Seurataan arvojen s��tymist� algoritmin aikana, eli ker�t��n
% s��detyt arvot seuraaviin taulukoihin
keratyt_k = k;
keratyt_b = b;

% seuraavaksi aloitetaan opettamaan datan perusteella
% opetetaan Rounds kertaa

Rounds = 20;
rate = 0.00002;

for J = 1:Rounds
   grad_k = 0;  % Jokaisen opetuskerran
   grad_b = 0;  % aikana ker�t��n uusi gradientti arvo, jolla
                 % s��det��n
                 
   for i = 1:M   % Jokaisella opetuskerralla ajetaa koko data 
      grad_k = grad_k + (( k*asunnonNelioMaara(i) + b) - asunnonHinta(i) ) * asunnonNelioMaara(i);
      grad_b = grad_b + (( k*asunnonNelioMaara(i) + b) - asunnonHinta(i) ) * 1;

   endfor
   % Jokaisen datapisteen derivaatta on nyt summattuna grad_t1 ja grad_t0
   % arvoihin. S��t� tapahtuu kuitenkin keskivarvon perusteella ja s��d�n
   % nopeutta voidaan s��t�� rate parametrilla.
   k = k - (rate/M)*grad_k;
   b = b - (rate/M)*grad_b;
   
   keratyt_k = [keratyt_k k];
   keratyt_b = [keratyt_b b];
   saadettySuora = xakseli*k + b;
   figure(4);plot(xakseli,saadettySuora,'-g');
   figure(2);stem(keratyt_k);title('Suoran kulmakertoimen arvojen muutos',"fontsize",20)
   figure(3);stem(keratyt_b);title('Suoran y-akselin leikkaus arvojen muutos',"fontsize",20)
   figure(4);plot(xakseli,saadettySuora,'-g');
   
endfor
hold off

