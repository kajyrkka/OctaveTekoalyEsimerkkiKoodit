function testaa_verkkoa(w1,w2,b1,b2,N)

  d = load('mnist.mat');
  kuvat = double(d.trainX);
  labels = double(d.trainY);
  oikeita = 0;
  vaaria = 0;

  
  paikka = round(60000*rand(1));

  for I = 1:N

       paikka = paikka + 1;
       if(paikka == 60000)
          paikka = 1;
       endif
       kuva = kuvat(paikka,:);
       label = labels(paikka);
       y= zeros(10,1);
       y(label+1) = 1;
      
       a0 = kuva';
       z1 = w1*a0 + b1;
       a1 = sigmoid(z1);
       
       z2 = w2*a1 + b2;
       a2 = sigmoid(z2);
       
       maksimi = max(a2);
       numero = find(a2 == maksimi) - 1;
       
      

       if(numero == label)
          oikeita = oikeita + 1;
       else
          vaaria = vaaria + 1;
       endif
    endfor
    %disp('verkko arvasi oikein')
    oikeita
    %disp('verkko arvasi v��rin')
    vaaria
    
 endfunction