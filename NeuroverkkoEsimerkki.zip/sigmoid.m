function out = sigmoid(in)
  %out = zeros(size(in));
  %out = exp(in) ./ (exp(in) + 1);
  
  out = 1./(1+exp(-in));
endfunction
