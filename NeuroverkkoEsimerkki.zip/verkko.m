clear;

layers = [784,30,10];

% alustetaan s��dett�v�t parametrit satunnaisesti
w1 = randn(layers(2),layers(1)); % 30 x 784 matriisi
w2 = randn(layers(3),layers(2)); % 10 x 30 matriisi
b1 = randn(layers(2),1);         % 30 x 1 pystymatriisi
b2 = randn(layers(3),1);         % 10 x 1 pystymatriisi

% otetaankin satunnaisten sijasta edellinen oppimistulos
load param

iterations = 5000;
epoc = 800;
rate = 0.8;



[w1,w2,b1,b2] = minibatch(w1,w2,b1,b2,iterations,epoc,rate);

