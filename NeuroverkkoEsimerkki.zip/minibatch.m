function [w1,w2,b1,b2] = minibatch(w1,w2,b1,b2,iterations,epoc,rate)
  d = load('mnist.mat');
  kuvat = double(d.trainX);
  labels = double(d.trainY);
  
  paikka = round(60000*rand(1));
  
  for I = 1:iterations
    
    nw1 = zeros(30,784);
    nw2 = zeros(10,30);
    nb1 = zeros(30,1);
    nb2 = zeros(10,1);
    
    
    for j = 1:epoc
       paikka = paikka + 1;
       if(paikka == 60000)
          paikka = 1;
       endif
       kuva = kuvat(paikka,:);
       label = labels(paikka);
       y= zeros(10,1);
       y(label+1) = 1;
       
       % lasketaan neuroverkon tulos t�m�n hetkisill� parametreilla
       a0 = kuva';
       z1 = w1*a0 + b1;
       a1 = sigmoid(z1);
       
       z2 = w2*a1 + b2;
       a2 = sigmoid(z2);
       
       % Ja kun tulos on selvill� saadaan kustannusfunktion virhe 
       % Backpropagation algoritmin avulla lasketaan lopusta alkuunp�in
       % miten kutakin s��dett�v� parametria pit�isi muuttaa, jotta
       % kustannusfunktion virhe minimoituisi
       % http://neuralnetworksanddeeplearning.com/
       dC = a2-y;
       dsigmoid = sigmoid(z2) .* (1-sigmoid(z2));
       error_L2 = dC .* dsigmoid;% BP1
       gb2 = error_L2;           % BP3
       gw2 = error_L2 * a1';     % BP4
       
       dsigmoid = sigmoid(z1) .* (1-sigmoid(z1));
       error_L1 = ((w2')*error_L2) .* dsigmoid;   %BP2
       gb1 = error_L1;
       gw1 = error_L1 * a0';

       
       nb1 = nb1 + gb1;
       nb2 = nb2 + gb2;
       nw1 = nw1 + gw1;
       nw2 = nw2 + gw2;
     
    endfor

    % Ja t�ss� sitten viimein s��det��n parametreja yhden epoc:n aikana
    % laskettujen derivaattojen avulla.
    w1 = w1 - (rate/epoc)*nw1;
    w2 = w2 - (rate/epoc)*nw2;
    b1 = b1 - (rate/epoc)*nb1;
    b2 = b2 - (rate/epoc)*nb2;

    % Ja s��d�n j�lkeen on aina kiva n�hd� miten s��t� vaikutti, 
    % eli ajetaan 100 kpl kuvia verkon l�pi ja katsotaan kuinka hyvin
    % verkko toimii s��d�n j�lkeen.
    testaa_verkkoa(w1,w2,b1,b2,100);

    I
  endfor

endfunction

  